# krunker-cheats
In light of recent (uneducated) claims made by Sportshot, I've decided to release the source of this cheat. He degraded the reputation of this cheat, making it look like I was "ip grabbing" and "stealing account logins". So, to him, and every other moron with less than half a brain, the source is now public.

OFFICIALLY ON THE CHROME WEBSTORE. NO NEED TO MANUALLY INSTALL.
https://chrome.google.com/webstore/detail/funks-krunker-cheat/becfndfgeanablnbjckpgfejgpibkhap

Cheats for https://krunker.io/ | Various modules for in-game advantages.

DEMO: https://www.youtube.com/watch?v=_-Z2yZ6FCFc
      https://youtu.be/LvACKPPgkkQ

## Usage
Instead of traditional krunker.io cheats, these cheats are injected manually, without a userscript manager. This ensures that the cheats remained unpatched, and makes it nearly impossible for the cheats to be detected.

## Notes
— This is the original source of this cheat, developed on 7/16/2019. Any reposts of this cheat on sites such as https://greasyfork.net are stolen, and may contain malicious code. This is the only location in which this cheat will ever be released.

— In the rare occasion of this cheat being patched, updates will be sent out whenever I have time to do so. There are no guarantees.

— This cheat is currently only functional on Google Chrome. There are no current plans to produce a version for any other browsers.
